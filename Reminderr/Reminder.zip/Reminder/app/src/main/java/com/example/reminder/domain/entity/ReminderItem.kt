package com.example.reminder.domain.entity

data class ReminderItem(val title: String = "", val description: String = "",val id: Int= 0)
